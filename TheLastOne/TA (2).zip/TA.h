/*
 * TA.h
 *
 *  Created on: 2018��12��29��
 *      Author: Brown
 */
#include "Config.h"
#ifndef TA_H_
#define TA_H_

void TIMERA_Init(void);
void TimerA_end(void);

#endif /* TA_H_ */
